/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;

/**
 *
 * @author wavelet
 */
public class Calculator extends Thread {
    
    List m_primes = new ArrayList<Long>();
    long m_limit = 0;
    boolean running = false;
    
    public Calculator() {
        m_primes.clear();
        m_primes.add(2L);
        m_primes.add(3L);
    }
    
    @Override
    public void run() {
        // For future development...
        running = true;
        running = false;
    }
    
    public String resetList() {
        if(running) { return "Thread is running. Reset later."; }
        m_primes.clear();
        m_primes.add(2L);
        m_primes.add(3L);
        return "Reseted!";
    }
    
    public List getList() {
        return m_primes;
    }
    
    public long calculateNext() {
        boolean found = false;
        long i = (long)m_primes.get(m_primes.size()-1); // Only odd numbers
        for(; i<Long.MAX_VALUE; i+=2L) {
            Iterator<Long> iter = m_primes.iterator();
            while(iter.hasNext()) {
                Long tmp = iter.next();
                if(i % tmp == 0L) {
                    found = true;
                    break;
                }
            }
            if(found) {
                found = false;
                continue; 
            }
            m_primes.add(i);
            return (long)m_primes.get(m_primes.size()-1);
        }
        return -1L;
    }
    
    public void resetAndCalculateUntil(long a_limit) {
        boolean found = false;
        m_primes.clear();
        m_primes.add(2L);
        long i=3L; // Only odd numbers
        for(; i<a_limit; i+=2L) {
            Iterator<Long> iter = m_primes.iterator();
            while(iter.hasNext()) {
                Long tmp = iter.next();
                if(i % tmp == 0L) {
                    found = true;
                    break;
                }
            }
            if(found) {
                found = false;
                continue; 
            }
            m_primes.add(i);
        }
    }
    
    public void continueAndCalculateUntil(long a_limit) {
        boolean found = false;
        long i = (long)m_primes.get(m_primes.size()-1); // Only odd numbers
        for(; i<a_limit; i+=2L) {
            Iterator<Long> iter = m_primes.iterator();
            while(iter.hasNext()) {
                Long tmp = iter.next();
                if(i % tmp == 0L) {
                    found = true;
                    break;
                }
            }
            if(found) {
                found = false;
                continue; 
            }
            m_primes.add(i);
        }
    }
}
