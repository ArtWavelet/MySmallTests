/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author wavelet
 */
public class CalculatorTest {
    
    public CalculatorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    /**
     * Test of getList method, of class Calculator.
     */
    @Test
    public void testGetList() {
        System.out.println("getList");
        Calculator instance = new Calculator();
        List expResult = new ArrayList<Long>();
        expResult.add(2L);
        expResult.add(3L);
        List result = instance.getList();
        if(result.size() != 2) {
            String out = "getList list size is " + result.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers.");
        }
        assertEquals(expResult, result);
    }
    
    /**
     * Test of calculateNext method, of class Calculator.
     */
    @Test
    public void testCalculateNext() {
        System.out.println("calculateNext");
        Calculator instance = new Calculator();
        long result = instance.calculateNext();
        long expResult = 5L;
        assertEquals(expResult, result);
        result = instance.calculateNext();
        expResult = 7L;
        assertEquals(expResult, result);
        result = instance.calculateNext();
        expResult = 11L;
        assertEquals(expResult, result);
        result = instance.calculateNext();
        expResult = 13L;
        assertEquals(expResult, result);
    }

    /**
     * Test of resetList method, of class Calculator.
     */
    @Test
    public void testResetList() {
        System.out.println("resetList");
        Calculator instance = new Calculator();
        instance.resetAndCalculateUntil(100L);
        List theList = instance.getList();
        if(theList.size() != 25) {
            String out = "List size is " + theList.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers before reset.");
        }
        String expResult = "Reseted!";
        String result = instance.resetList();
        assertEquals(expResult, result);
        theList = instance.getList();
        if(theList.size() != 2) {
            String out = "List size is " + theList.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers after reset.");
        }
    }


    /**
     * Test of resetAndCalculateUntil method, of class Calculator.
     */
    @Test
    public void testResetAndCalculateUntil() {
        System.out.println("resetAndCalculateUntil");
        long a_limit = 0L;
        Calculator instance = new Calculator();
        instance.resetAndCalculateUntil(100);
        List theList = instance.getList();
        if(theList.size() != 25) {
            String out = "List size is " + theList.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers before reset.");
        }
        //List expResult = new ArrayList<Long>();
        long[] expResult = {2L, 3L, 5L, 7L, 11L, 13L, 17L, 19L, 23L, 29L, 31L, 37L, 41L, 43L, 47L, 53L, 59L, 61L, 67L, 71L, 73L, 79L, 83L, 89L, 97L};
        Iterator<Long> iter = theList.iterator();
        for(int i=0; i < 25; ++i) {
            if(iter.hasNext() == false) { fail("List size problem?"); break; }
            long val = iter.next();
            /*if(expResult[i] != val) {
                String out = "Wrong number in the list at index " + i;
                fail(out); break;
            }*/
            assertEquals(expResult[i], val);
        }
    }

    /**
     * Test of continueAndCalculateUntil method, of class Calculator.
     */
    @Test
    public void testContinueAndCalculateUntil() {
        System.out.println("continueAndCalculateUntil");
        long a_limit = 100L;
        Calculator instance = new Calculator();
        instance.resetAndCalculateUntil(50);
        List theList = instance.getList();
        if(theList.size() != 15) {
            String out = "List size is " + theList.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers before continued calculation.");
        }
        instance.continueAndCalculateUntil(100);
        theList = instance.getList();
        if(theList.size() != 25) {
            String out = "List size is " + theList.size();
            System.out.println(out);
            fail("The test case has wrong number of numbers after continued calculation.");
        }
        //List expResult = new ArrayList<Long>();
        long[] expResult = {2L, 3L, 5L, 7L, 11L, 13L, 17L, 19L, 23L, 29L, 31L, 37L, 41L, 43L, 47L, 53L, 59L, 61L, 67L, 71L, 73L, 79L, 83L, 89L, 97L};
        Iterator<Long> iter = theList.iterator();
        for(int i=0; i < 25; ++i) {
            if(iter.hasNext() == false) { fail("List size problem?"); break; }
            long val = iter.next();
            /*if(expResult[i] != val) {
                String out = "Wrong number in the list at index " + i;
                fail(out); break;
            }*/
            assertEquals(expResult[i], val);
        }
    }
    
}
