/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package App.classes;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author wavelet
 */
public class PhoneNroListListener implements ListSelectionListener {
        SimpleContactsApp theApp = null;
    
    public PhoneNroListListener( SimpleContactsApp app ) {
        theApp = app;
    }
    
    public void valueChanged(ListSelectionEvent e) {
        ListSelectionModel lsm = (ListSelectionModel)e.getSource();
        if (lsm.isSelectionEmpty()) {
            return;
        }
        int selInd = lsm.getMinSelectionIndex();
        theApp.setSelectedPhoneNro(selInd);
    }
}
